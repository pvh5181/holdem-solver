#include "include/ui/detailwindowsetting.h"

DetailWindowSetting::DetailWindowSetting(){
    this->mode = DetailWindowMode::STRATEGY;
}
